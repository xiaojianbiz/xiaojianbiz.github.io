INSERT INTO `[#DB_PREFIX#]system_setting` (`varname`, `value`) VALUES ('integral_system_config_answer_change_source', 's:1:"Y";');
